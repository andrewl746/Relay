# Relay — logo files

One mark, three frame weights, plus icon cuts. Ink `#1C1A15` on paper `#F2EFE6`.
Type: Archivo 700 at width 64%, tracking 0.07em. Numbers and small labels: IBM Plex Mono.
The stamp is always rotated −1.5° counter-clockwise. Never straighten it, never tilt it further, never mirror it.

Subtitle: "Sharing is caring." — set in Archivo 500 at width 86%, inside the frame under the wordmark.
The tagline "One of these on the street, not one in every room." is not part of the logo.

---

## Files

**relay-stamp-primary-ink.png**
The full stamp: double rule, subtitle, and the "Handed on __ / __" slot. This is the signature
version — use it where the mark is the main event and it can be seen at 200px wide or more:
about pages, posters, the printed handoff receipt, the back of a sticker sheet, slide 1 of a pitch.

**relay-stamp-primary-reversed.png**
Same lockup, paper on ink, with its dark ground included. Use on dark headers, projector slides,
and photos. Do not recolour it — the reversed cut only ever runs paper on `#1C1A15`.

**relay-stamp-single-rule.png**
One rule, no subtitle, no date slot. The everyday lockup: site header, email signature, tote,
anywhere the double frame would turn into noise below ~150px wide. This is the default for the
product UI.

**relay-stamp-stacked.png**
Frame with "Waterloo ON" beneath the rule. For square or near-square spaces — sticker, tag,
social avatar, the corner of a poster. Use when the city matters (campus posters, flyers on
the street).

**relay-wordmark-plain.png**
The word alone, no frame, no tilt. Use when the mark sits inside something already ruled or
boxed — a table header, a partner lockup, a document footer, embroidery. Never add your own
box: if it needs a frame, use one of the stamp files.

**relay-favicon-16.png** (16×16, plus relay-favicon-16@4x.png at 64×64)
Pressed square with a single condensed R. Browser tab, list rows, anywhere under 24px. The
inner rule is deliberately gone at this size.

**relay-favicon-32.png** (32×32, plus relay-favicon-32@4x.png at 128×128)
Same construction at 32px — retina tabs, bookmarks, small avatars.

**relay-favicon-32-outline.png** (32×32, plus relay-favicon-32-outline@4x.png at 128×128)
Outline press: ink rule, paper interior. For use *on* an ink or photographic ground where the
solid square would disappear, and for one-colour stamping onto physical objects.

**relay-app-icon-64.png** (rendered 256px, for a 64px slot)
The R with its frame restored — the inner rule returns above ~40px. Home-screen icon, app
switcher, store listing at small sizes.

**relay-app-icon-512.png** (512×512)
Largest icon cut, same construction. Store listings, README headers, anything needing a big
square icon.

---

## Clear space and minimum sizes

- Clear space: 0.85 × cap height on every side. Nothing sits inside it.
- Stamp lockups: minimum 96px wide (single rule), 150px wide (double rule with date slot).
- Icons: use the cut made for the size — never scale the 512 down to 16. The @4x files are the
  same construction for retina and print; the plain 16/32 files are pixel-exact for browser use.
- All lockups are rendered at 4× and can be scaled down freely; scaling up past 100% will soften
  the hairlines.

## Don't

- No colour in the logo. Green `#3E7A4C`, red `#C6371B` and amber `#E0A43A` mean in use, idle
  and money; they never decorate the mark.
- No rounded corners, shadows, gradients, or outlines added to the frame.
- No stretching: the width axis is set at 64% and stays there.
- No second tilt. −1.5° is the only imperfection in the system.
